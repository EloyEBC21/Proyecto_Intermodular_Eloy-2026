-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: tienda_db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `partidas`
--

DROP TABLE IF EXISTS `partidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partidas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha` datetime(6) DEFAULT NULL,
  `juego` varchar(255) DEFAULT NULL,
  `jugadores_apuntados` int NOT NULL,
  `jugadores_max` int NOT NULL,
  `lugar` varchar(255) DEFAULT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partidas`
--

LOCK TABLES `partidas` WRITE;
/*!40000 ALTER TABLE `partidas` DISABLE KEYS */;
INSERT INTO `partidas` VALUES (1,'2026-06-05 18:30:00.000000','Dungeons & Dragons 5e',4,6,'Game & Grill - Local','Noche de D&D: La Mina Perdida'),(2,'2026-06-07 17:00:00.000000','Los Colonos de Catán',8,12,'Game & Grill - Local','Torneo Catan'),(3,'2026-06-10 19:15:00.000000','Magic MTG',6,8,'Game & Grill - Local','Magic: The Gathering Commander'),(4,'2026-06-12 20:00:00.000000','Varios juegos disponibles',3,10,'Game & Grill - Local','Mesa libre: Juegos variados');
/*!40000 ALTER TABLE `partidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plato_producto`
--

DROP TABLE IF EXISTS `plato_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plato_producto` (
  `plato_id` bigint NOT NULL,
  `producto_id` bigint NOT NULL,
  KEY `FKo0shew856er96gihfd7m4x2l9` (`producto_id`),
  KEY `FKhnlvv0mwci3pxbfii8b20tykg` (`plato_id`),
  CONSTRAINT `FKhnlvv0mwci3pxbfii8b20tykg` FOREIGN KEY (`plato_id`) REFERENCES `platos` (`id`),
  CONSTRAINT `FKo0shew856er96gihfd7m4x2l9` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plato_producto`
--

LOCK TABLES `plato_producto` WRITE;
/*!40000 ALTER TABLE `plato_producto` DISABLE KEYS */;
/*!40000 ALTER TABLE `plato_producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platos`
--

DROP TABLE IF EXISTS `platos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `platos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platos`
--

LOCK TABLES `platos` WRITE;
/*!40000 ALTER TABLE `platos` DISABLE KEYS */;
/*!40000 ALTER TABLE `platos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `categoria` varchar(255) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `precio` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'Entrantes','Con queso, guacamole y jalapeños','Nachos Supreme',8.5),(2,'Entrantes','8 unidades con salsa BBQ','Alitas de BBQ',9),(3,'Entrantes','6 unidades con salsa de miel y mostaza','Tequeños',7.5),(4,'Entrantes','Crujientes con salsa agridulce','Aros de Cebolla',6),(5,'Ensaladas','Pollo, picatostes, parmesano y salsa César','Ensalada César',9.5),(6,'Ensaladas','Tomate, mozzarella fresca y albahaca','Ensalada Caprese',8.5),(7,'Hamburguesas','Doble carne, bacon, queso y patatas','Hamburguesa Gamer',12.5),(8,'Hamburguesas','Hamburguesa de garbanzos, aguacate y rúcula','Hamburguesa Veggie',11),(9,'Hamburguesas','Carne de ternera con triple queso fundido','Hamburguesa Doble Queso',13),(10,'Pizzas','Pizza familiar con ingredientes épicos','Pizza D&D',15),(11,'Pizzas','Tomate, mozzarella y albahaca','Pizza Margarita',10),(12,'Pizzas','Carne picada, bacon y salsa barbacoa','Pizza Barbacoa',13.5),(13,'Bocadillos','Jamón serrano, tomate y aceite de oliva','Bocadillo Serrano',6.5),(14,'Bocadillos','Pechuga, lechuga, tomate y mayonesa','Bocadillo de Pollo',7),(15,'Bebidas','Refresco de cola bien frío','Coca-Cola',2.5),(16,'Bebidas','Cerveza local de estilo IPA','Cerveza Artesana',4),(17,'Bebidas','Botella de 50cl','Agua Mineral',1.5),(18,'Salsas','Salsa casera ahumada','Salsa Barbacoa',0.5),(19,'Salsas','Ajo suave y aceite','Alioli',0.5),(20,'Postres','Con helado de vainilla y nueces','Brownie de Chocolate',5.5),(21,'Postres','Casera con mermelada de frutos rojos','Tarta de Queso',5),(22,'Postres','Dos bolas de helado artesano','Helado de Vainilla',4);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `edad` int NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `juegos` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `usuario` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,28,'guille@mail.com','Dungeons & Dragons, Magic: The Gathering','1234','Guillermo');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-21 12:09:35
